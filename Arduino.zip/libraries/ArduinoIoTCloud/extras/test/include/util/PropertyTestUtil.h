/*
 * Copyright (c) 2020 Arduino.  All rights reserved.
 */

#ifndef PROPERTY_TEST_UTIL_H_
#define PROPERTY_TEST_UTIL_H_

/**************************************************************************************
   FUNCTION DECLARATION
 **************************************************************************************/

extern "C" unsigned long getTime();

#endif /* PROPERTY_TEST_UTIL_H_ */
